"""Experimental exact +, -, * constants. No resource-policy qualification.

Values are (Fraction, floating-category) pairs. Binding caches use declaration
identity. This module never follows a declaration recursively or evaluates calls.
"""
from fractions import Fraction
from a7.ast_nodes import NodeKind, LiteralKind, UnaryOp, BinaryOp


def evaluate(root, lookup, bindings):
    """Evaluate one expression with an explicit postorder stack, or return None."""
    if root is None:
        return None
    values = {}
    stack = [(root, False)]
    while stack:
        node, ready = stack.pop()
        key = id(node)
        saved = getattr(node, 'exact_constant', None)
        if saved is not None:
            values[key] = saved
        elif node.kind == NodeKind.LITERAL:
            if node.literal_kind == LiteralKind.INTEGER:
                values[key] = (Fraction(node.literal_value), False)
            elif node.literal_kind == LiteralKind.FLOAT:
                value = Fraction(node.raw_text)
                floating = 'negative_zero' if not value and node.raw_text.startswith('-') else True
                values[key] = (value, floating)
            else:
                return None
        elif node.kind == NodeKind.IDENTIFIER:
            symbol = lookup(node.name)
            value = bindings.get(id(symbol.node)) if symbol and symbol.node else None
            if value is None:
                return None
            values[key] = value
        elif node.kind == NodeKind.UNARY and node.operator == UnaryOp.NEG:
            if not ready:
                stack.extend([(node, True), (node.operand, False)])
            else:
                value, floating = values[id(node.operand)]
                values[key] = (-value, ('negative_zero' if floating != 'negative_zero' else True) if floating and not value else floating)
        elif node.kind == NodeKind.BINARY and node.operator in {BinaryOp.ADD, BinaryOp.SUB, BinaryOp.MUL}:
            if not ready:
                stack.extend([(node, True), (node.right, False), (node.left, False)])
            else:
                left, lf = values[id(node.left)]
                right, rf = values[id(node.right)]
                if node.operator == BinaryOp.ADD:
                    result = left + right
                elif node.operator == BinaryOp.SUB:
                    result = left - right
                else:
                    result = left * right
                floating = bool(lf or rf)
                if not result and floating:
                    ln = left < 0 or lf == 'negative_zero'
                    rn = right < 0 or rf == 'negative_zero'
                    negative = (ln != rn) if node.operator == BinaryOp.MUL else (ln and (rn if node.operator == BinaryOp.ADD else not rn))
                    if negative:
                        floating = 'negative_zero'
                values[key] = (result, floating)
        else:
            return None
    return values[id(root)]


def decimal_text(value):
    """Serialize a terminating rational exactly, without a decimal context."""
    numerator, denominator = value.numerator, value.denominator
    twos = fives = 0
    while denominator % 2 == 0:
        denominator //= 2
        twos += 1
    while denominator % 5 == 0:
        denominator //= 5
        fives += 1
    if denominator != 1:
        raise ValueError('experimental serializer only supports terminating decimals')
    places = max(twos, fives)
    scaled = abs(numerator) * 2 ** (places - twos) * 5 ** (places - fives)
    digits = str(scaled).zfill(places + 1)
    sign = '-' if numerator < 0 else ''
    if places:
        return sign + digits[:-places] + '.' + digits[-places:]
    return sign + digits + '.0'


def materialize(node, exact, integer=False):
    """Replace this use only. The binding's cached exact pair stays unchanged."""
    value, floating = exact
    node.exact_constant = exact
    node.kind = NodeKind.LITERAL
    node.literal_kind = LiteralKind.FLOAT if floating and not integer else LiteralKind.INTEGER
    if node.literal_kind == LiteralKind.INTEGER:
        node.literal_value = value.numerator
        node.raw_text = str(value.numerator)
    else:
        node.raw_text = '-0.0' if floating == 'negative_zero' else decimal_text(value)
        node.literal_value = float(node.raw_text)
    # Remove obsolete children so subsequent visitors see only the materialized use.
    node.left = node.right = node.operand = None
    node.name = None
