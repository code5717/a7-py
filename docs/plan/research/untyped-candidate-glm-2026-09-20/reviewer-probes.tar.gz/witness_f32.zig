pub fn main() void {
    const x: f32 = @as(f32, @bitCast(@as(u32, 1065353217)));
    _ = x;
}
