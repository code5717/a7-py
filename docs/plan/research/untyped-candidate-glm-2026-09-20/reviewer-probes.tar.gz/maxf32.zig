pub fn main() void {
    const x: f32 = @as(f32, @bitCast(@as(u32, 2139095039)));
    _ = x;
}
