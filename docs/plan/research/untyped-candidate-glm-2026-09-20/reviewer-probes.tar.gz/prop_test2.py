import sys
import random, struct
from fractions import Fraction as F
from a7.exact_constants import ieee_bits, evaluate, ExactArithmeticError
from a7.ast_nodes import (NodeKind, LiteralKind, UnaryOp, BinaryOp, ASTNode,
                          create_literal, create_identifier, create_binary_expr)

def ref(value, width):
    """Reference: locate binade, quantize by floor/ceil + exact distance, ties to even."""
    if width == 32: p, emin, emax, bias = 24, -126, 127, 127
    else: p, emin, emax, bias = 53, -1022, 1023, 1023
    sign = 1 if value < 0 else 0
    v = abs(value)
    if v == 0: return 0, False
    e = v.numerator.bit_length() - v.denominator.bit_length()
    if F(2) ** e > v: e -= 1
    assert F(2) ** e <= v < F(2) ** (e + 1)
    s = F(2) ** (max(e, emin) - (p - 1))     # target spacing
    k = v / s
    lo = k.numerator // k.denominator
    hi = lo + 1
    if k - lo < hi - k: m = lo
    elif hi - k < k - lo: m = hi
    else: m = lo if lo % 2 == 0 else hi
    if m == 1 << p:                            # carried into next binade
        m >>= 1; e += 1
    if e < emin and m == 1 << (p - 1):         # rounded up to exactly min normal
        e = emin
    if e > emax: return None, True             # -> inf
    if m < 1 << (p - 1): return (sign << (width - 1)) | m, False
    return (sign << (width - 1)) | ((e + bias) << (p - 1)) | (m - (1 << (p - 1))), False

random.seed(20260920)
cases = []
for _ in range(40000):
    n = random.randint(0, 2 ** random.randint(1, 130))
    d = random.randint(1, 2 ** random.randint(1, 130))
    cases.append(F(n, d) * F(10) ** random.randint(-340, 340))
for p2 in range(-1080, 140):
    t = F(2) ** p2
    for delta in (F(1, 2 ** 400), -F(1, 2 ** 400), F(1, 3), -F(1, 3), F(0)):
        cases.append(t + delta)
for base in (F(1), F(2) ** -125, F(2) ** -148, F(2) ** 100, F(2) ** -1021, F(2) ** -1073):
    for h in (F(1, 2), F(1, 3), F(2, 3)):
        cases.append(base + h * F(2) ** -23 if base >= F(2) ** -126 else base + h * F(2) ** -149)
        cases.append(base + h * F(2) ** -52 if base >= F(2) ** -1022 else base + h * F(2) ** -1074)

bad = bad64 = 0
for v in cases:
    if v <= 0: v = v  # keep; sign tested via negation below
    for neg in (False, True):
        val = -v if neg else v
        for w in (32, 64):
            cat = 'negative_zero' if (val == 0 and neg) else True
            if val == 0:
                want = (1 << (width_sign := w - 1)) if neg else 0
                assert ieee_bits((val, cat), w) == want, (neg, w)
                continue
            try:
                got, ovf = ieee_bits((val, cat), w), False
            except ExactArithmeticError:
                got, ovf = None, True
            r, rovf = ref(val, w)
            if (got, ovf) != (r, rovf):
                bad += 1
                if bad < 8: print("MISMATCH", w, val, (got, ovf), (r, rovf))
            if w == 64 and not ovf and val != 0 and abs(val) < F(2) ** 1024:
                f = val.numerator / val.denominator
                cross = struct.unpack('>Q', struct.pack('>d', f))[0]
                if cross != got:
                    bad64 += 1
                    if bad64 < 8: print("CPYTHON-XCHECK FAIL", val, got, cross)
print(f"ieee_bits: {len(cases)} families x2 signs x2 widths, ref mismatches={bad}, cpython-f64 mismatches={bad64}")

def lint(n): return create_literal(LiteralKind.INTEGER, n, str(n))
def flit(s): return create_literal(LiteralKind.FLOAT, float(s), s)
def bin_(op, l, r): return ASTNode(kind=NodeKind.BINARY, left=l, operator=op, right=r)
def un_(op, o): return ASTNode(kind=NodeKind.UNARY, operator=op, operand=o)

tests = [
    (bin_(BinaryOp.DIV, lint(5), lint(2)), F(2), False),
    (bin_(BinaryOp.DIV, un_(UnaryOp.NEG, lint(5)), lint(2)), F(-2), False),
    (bin_(BinaryOp.MOD, un_(UnaryOp.NEG, lint(5)), lint(2)), F(-1), False),
    (bin_(BinaryOp.MOD, lint(5), un_(UnaryOp.NEG, lint(2))), F(1), False),
    (bin_(BinaryOp.DIV, flit('5.0'), lint(2)), F(5, 2), True),
    (bin_(BinaryOp.MOD, flit('-5.5'), flit('2.0')), F(-3, 2), True),
    (bin_(BinaryOp.DIV, flit('1.0'), flit('3.0')), F(1, 3), True),
    (un_(UnaryOp.NEG, flit('0.0')), F(0), 'negative_zero'),
    (un_(UnaryOp.NEG, un_(UnaryOp.NEG, flit('0.0'))), F(0), True),
    (bin_(BinaryOp.ADD, flit('-0.0'), flit('-0.0')), F(0), 'negative_zero'),
    (bin_(BinaryOp.ADD, flit('-0.0'), flit('0.0')), F(0), True),
    (bin_(BinaryOp.SUB, flit('-0.0'), flit('0.0')), F(0), 'negative_zero'),
    (bin_(BinaryOp.MUL, flit('-0.0'), flit('2.0')), F(0), 'negative_zero'),
    (bin_(BinaryOp.DIV, flit('0.0'), flit('-2.0')), F(0), 'negative_zero'),
    (bin_(BinaryOp.MOD, flit('-4.0'), flit('2.0')), F(0), 'negative_zero'),
    (bin_(BinaryOp.MOD, flit('4.0'), un_(UnaryOp.NEG, flit('2.0'))), F(0), True),
    (bin_(BinaryOp.MUL, lint(255), lint(1)), F(255), False),
    (bin_(BinaryOp.ADD, flit('0.01'), flit('0.02')), F(3, 100), True),
    (bin_(BinaryOp.SUB, flit('0.3'), flit('0.1')), F(2, 10), True),
    (bin_(BinaryOp.ADD, lint(1), flit('2.0')), F(3), True),
]
fail = sum(1 for e, wv, wc in tests if (lambda r: r is None or r[0] != wv or r[1] != wc)(evaluate(e, lambda n: None, {})))
for e, wv, wc in tests:
    r = evaluate(e, lambda n: None, {})
    if r is None or r[0] != wv or r[1] != wc: print("EVAL FAIL want", (wv, wc), "got", r)
print(f"evaluate semantics: {len(tests)} cases, {fail} failures")
for op in (BinaryOp.AND, BinaryOp.OR, BinaryOp.BIT_SHL, BinaryOp.BIT_SHR, BinaryOp.BIT_AND, BinaryOp.BIT_OR, BinaryOp.BIT_XOR):
    assert evaluate(bin_(op, lint(1), lint(2)), lambda n: None, {}) is None, op
assert evaluate(ASTNode(kind=NodeKind.UNARY, operator=UnaryOp.BIT_NOT, operand=lint(3)), lambda n: None, {}) is None
try:
    evaluate(bin_(BinaryOp.DIV, lint(1), lint(0)), lambda n: None, {}); print("ZERO DIV NOT RAISED")
except ExactArithmeticError: pass
print("unsupported fallbacks + zero divisor: OK")
