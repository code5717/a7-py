const std = @import("std");
var __a7_io: ?std.Io = null;
fn __a7_stdout_print(comptime fmt: []const u8, args: anytype) void {
    var __a7_stream_buf: [1024]u8 = undefined;
    var __a7_writer = std.Io.File.stdout().writerStreaming(__a7_io.?, &__a7_stream_buf);
    __a7_writer.interface.print(fmt, args) catch @panic("a7 stdout write failed");
    __a7_writer.interface.flush() catch @panic("a7 stdout flush failed");
}
pub fn main(init: std.process.Init) void {
    __a7_io = init.io;
    __a7_user_main();
}

fn __a7_user_main() void {
    const t: f64 = @as(f64, @bitCast(@as(u64, 4591870180066957722)));

    if (((t + @as(f64, @bitCast(@as(u64, 4596373779694328218)))) == @as(f64, @bitCast(@as(u64, 4599075939470750515))))) {
        __a7_stdout_print("untyped-style\n", .{});
    } else {
        __a7_stdout_print("ieee\n", .{});
    }
}
