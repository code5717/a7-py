pub fn main() void {
    const x: f64 = @as(f64, @bitCast(@as(u64, 4607182418800017409)));
    _ = x;
}
