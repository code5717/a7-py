import sys; sys.modules["a7"] = type(sys)("a7"); sys.modules["a7"].__path__ = ["/home/cx89/Projects/pl-dev/a7-py/tmp/untyped-constants-next/review-candidate-2/a7"]
import random, struct, sys
from fractions import Fraction as F
sys.path.insert(0, "/home/cx89/Projects/pl-dev/a7-py/tmp/untyped-constants-next/review-candidate-2")
from a7.exact_constants import ieee_bits, evaluate, ExactArithmeticError
from a7.ast_nodes import (NodeKind, LiteralKind, UnaryOp, BinaryOp, ASTNode,
                          create_literal, create_identifier, create_binary_expr)

def ref_grid(value, width):
    """Independent reference: round on the global subnormal grid by distance comparison."""
    if width == 32: p, emin, emax, bias = 24, -126, 127, 127
    else: p, emin, emax, bias = 53, -1022, 1023, 1023
    sign = 1 if value < 0 or (value == 0 and 0) else 0
    v = abs(value)
    if v == 0: return 0, False
    q = F(2) ** (emin - (p - 1))          # subnormal grid spacing
    k = v / q
    lo = k.numerator // k.denominator
    hi = lo + 1
    dlo, dhi = k - lo, hi - k
    if dlo < dhi: sig = lo
    elif dhi < dlo: sig = hi
    else: sig = lo if lo % 2 == 0 else hi
    r = sig * q                            # rounded magnitude
    if r >= F(2) ** (emax + 1): return None, True   # overflow -> inf
    if sig == 0: return 0, False
    # unbiased exponent of r
    e = r.numerator.bit_length() - r.denominator.bit_length()
    if F(2) ** e > r: e -= 1
    if e < emin:
        return sign << (width - 1) | sig, False
    frac = sig >> (e - (emin - (p - 1))) if e > emin - (p - 1) else sig
    # recompute fraction directly from r for independence
    m = r / F(2) ** e                      # in [1,2)
    sigm = m * (F(2) ** (p - 1))
    assert sigm.denominator == 1
    si = sigm.numerator
    assert (p - 1) <= si.bit_length() <= p
    return (sign << (width - 1)) | ((e + bias) << (p - 1)) | (si - (1 << (p - 1))), False

random.seed(20260920)
cases = []
# random rationals with mixed magnitudes
for _ in range(30000):
    n = random.randint(0, 2**random.randint(1, 120))
    d = random.randint(1, 2**random.randint(1, 120))
    e10 = random.randint(-330, 330)
    cases.append(F(n, d) * F(10) ** e10)
# midpoints and neighbors of powers of two (normal + subnormal range)
for p2 in list(range(-160, 130)) + [-149, -150, -126, -125, -127, -1022, -1023, -1024, -1074, -1075]:
    t = F(2) ** p2
    for delta in (F(1, 2**300), -F(1, 2**300), F(1, 3), -F(1, 3)):
        cases.append(t + delta)
    cases.append(t)
# exact ties between adjacent f32 values near 1.0 and near subnormals
for base in (F(1), F(2)**-125, F(2)**-148, F(2)**100, F(2)**-1021, F(2)**-1073, F(1) + F(2)**-52):
    ulp32 = F(2) ** -23 if base >= F(2)**-126 else F(2) ** -149
    for k in (-3, -1, 0, 1, 3):
        cases.append(base + k * ulp32 / 2)

bad = 0
for v in cases:
    for w, sign_pairs in ((32, ((1, 1), (-1, -1))), (64, ((1, 1),))):
        for mul, exp_sign in sign_pairs:
            val = v * exp_sign
            cat = 'negative_zero' if val == 0 and exp_sign < 0 else (True if val else True)
            try:
                got = ieee_bits((val, cat if val == 0 else True), w)
                ovf = False
            except ExactArithmeticError:
                got, ovf = None, True
            ref, rovf = ref_grid(val, w)
            # cross-check f64 against CPython correctly-rounded int/int division when exact
            cross = None
            if w == 64 and not ovf and abs(val) < F(10)**308 * F(1,1) and val != 0:
                f = val.numerator / val.denominator   # correctly rounded
                if f in (float('inf'),):
                    cross = 'inf'
                else:
                    cross = struct.unpack('>Q', struct.pack('>d', f))[0]
            if (got, ovf) != (ref, rovf) or (cross is not None and cross not in ('inf',) and cross != got):
                bad += 1
                if bad < 10:
                    print("MISMATCH", w, val, "got", (got, ovf), "ref", (ref, rovf), "cross", cross)
print("ieee_bits property:", len(cases), "families,", bad, "mismatches")

# ---- evaluate() semantics on synthetic ASTs ----
def lint(n): return create_literal(LiteralKind.INTEGER, n, str(n))
def flit(s): return create_literal(LiteralKind.FLOAT, float(s), s)
def bin_(op, l, r): return ASTNode(kind=NodeKind.BINARY, left=l, operator=op, right=r)
def un_(op, o): return ASTNode(kind=NodeKind.UNARY, operator=op, operand=o)

tests = []
def t(expr, want_val, want_cat):
    tests.append((expr, F(want_val) if not isinstance(want_val, F) else want_val, want_cat))

t(bin_(BinaryOp.DIV, lint(5), lint(2)), 2, False)
t(bin_(BinaryOp.DIV, un_(UnaryOp.NEG, lint(5)), lint(2)), -2, False)
t(bin_(BinaryOp.MOD, un_(UnaryOp.NEG, lint(5)), lint(2)), -1, False)
t(bin_(BinaryOp.MOD, lint(5), un_(UnaryOp.NEG, lint(2))), 1, False)
t(bin_(BinaryOp.DIV, flit('5.0'), lint(2)), F('5')/2, True)
t(bin_(BinaryOp.MOD, flit('-5.5'), flit('2.0')), F('-3')/2, True)
t(bin_(BinaryOp.DIV, flit('1.0'), flit('3.0')), F(1,3), True)
t(un_(UnaryOp.NEG, flit('0.0')), 0, 'negative_zero')
t(un_(UnaryOp.NEG, un_(UnaryOp.NEG, flit('0.0'))), 0, True)
t(bin_(BinaryOp.ADD, flit('-0.0'), flit('-0.0')), 0, 'negative_zero')
t(bin_(BinaryOp.ADD, flit('-0.0'), flit('0.0')), 0, True)
t(bin_(BinaryOp.SUB, flit('-0.0'), flit('0.0')), 0, 'negative_zero')
t(bin_(BinaryOp.MUL, flit('-0.0'), flit('2.0')), 0, 'negative_zero')
t(bin_(BinaryOp.DIV, flit('0.0'), flit('-2.0')), 0, 'negative_zero')
t(bin_(BinaryOp.MOD, flit('-4.0'), flit('2.0')), 0, 'negative_zero')
t(bin_(BinaryOp.MOD, flit('4.0'), un_(UnaryOp.NEG, flit('2.0'))), 0, True)
t(bin_(BinaryOp.MUL, lint(255), lint(1)) , 255, False)  # int category stays int
t(bin_(BinaryOp.ADD, flit('1e-2'), flit('2e-2')), F(3,100), True)
t(bin_(BinaryOp.SUB, flit('0.3'), flit('0.1')), F('0.3')-F('0.1'), True)

fail = 0
for expr, wv, wc in tests:
    res = evaluate(expr, lambda name: None, {})
    if res is None or res[0] != wv or res[1] != wc:
        fail += 1
        print("EVAL FAIL", "want", (wv, wc), "got", res)
print("evaluate semantics:", len(tests), "cases,", fail, "failures")

# unsupported operators must return None, not raise
for op in (BinaryOp.AND, BinaryOp.OR, BinaryOp.SHL, BinaryOp.SHR, BinaryOp.BIT_AND, BinaryOp.BIT_XOR):
    r = evaluate(bin_(op, lint(1), lint(2)), lambda n: None, {})
    assert r is None, op
r = evaluate(ASTNode(kind=NodeKind.UNARY, operator=UnaryOp.BIT_NOT, operand=lint(3)), lambda n: None, {})
assert r is None
print("unsupported fallbacks: OK (None)")
# zero divisor raises
try:
    evaluate(bin_(BinaryOp.DIV, lint(1), lint(0)), lambda n: None, {})
    print("ZERO DIV: no raise - BAD")
except ExactArithmeticError:
    print("zero divisor raises: OK")
