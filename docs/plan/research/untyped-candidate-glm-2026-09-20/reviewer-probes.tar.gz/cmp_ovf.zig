pub fn main() void {
    const y: bool = true;
    _ = y;
}
