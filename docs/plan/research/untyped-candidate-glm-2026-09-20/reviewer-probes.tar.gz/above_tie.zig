pub fn main() void {
    const x: f64 = @as(f64, @bitCast(@as(u64, 5183643170835005440)));
    _ = x;
}
