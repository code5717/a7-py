pub fn main() void {
    const x: f64 = @as(f64, @bitCast(@as(u64, 9218868437227405311)));
    _ = x;
}
