pub fn main() void {
    const x: f64 = @as(f64, @bitCast(@as(u64, 1)));
    _ = x;
}
