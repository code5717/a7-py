pub fn main() void {
    const x: f64 = @as(f64, @bitCast(@as(u64, 9223372036854775808)));
    _ = x;
}
